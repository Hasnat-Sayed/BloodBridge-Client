import { createBrowserRouter } from "react-router";
import RootLayout from "../layouts/RootLayout/RootLayout";
import Home from "../Pages/Home";
import Login from "../Pages/Login";
import Register from "../Pages/Register";
import DashboardLayout from "../layouts/DashboardLayout/DashboardLayout";
import MainDashboard from "../Pages/Dashboard/DashboardHome/MainDashboard";
import CreateRequest from "../Pages/Dashboard/DonorPages/CreateRequest";
import AllUsers from "../Pages/Dashboard/AdminPages/AllUsers";
import PrivateRoute from "./PrivateRoute";
import MyRequests from "../Pages/Dashboard/DonorPages/MyRequests";
import Funding from "../Pages/Funding";
import PaymentSuccess from "../Pages/PaymentSuccess";
import SearchRequest from "../Pages/SearchRequest";
import DonationRequests from "../Pages/DonationRequests";
import DonationDetails from "../Pages/DonationDetails";
import EditRequest from "../Pages/Dashboard/EditRequest";
import Profile from "../Pages/Dashboard/Profile";
import ErrorPage from "../Pages/ErrorPage";
import AllRequestAdmin from "../Pages/Dashboard/AdminPages/AllRequestAdmin";
import AllRequestVolunteer from "../Pages/Dashboard/VolunteerPages/AllRequestVolunteer";
import AdminRoutes from "./AdminRoutes";
import VolunteerRoutes from "./VolunteerRoutes";
import Review from "../Pages/Dashboard/DonorPages/Review";
import ContactUs from "../Pages/ContactUs";
import AboutUs from "../Pages/AboutUs";

const router = createBrowserRouter([
    {
        path: "/",
        errorElement: <ErrorPage></ErrorPage>,
        element: <RootLayout></RootLayout>,
        children: [
            {
                index: true,
                element: <Home></Home>
            },
            {
                path: '/login',
                element: <Login></Login>
            },
            {
                path: '/register',
                element: <Register></Register>
            },
            {
                path: '/funding',
                element: <PrivateRoute><Funding></Funding></PrivateRoute>
            },
            {
                path: '/payment-success',
                element: <PaymentSuccess></PaymentSuccess>
            },
            {
                path: '/payment-cancelled',
                element: <PaymentSuccess></PaymentSuccess>
            },
            {
                path: '/search',
                element: <SearchRequest></SearchRequest>
            },
            {
                path: '/contact',
                element: <ContactUs></ContactUs>
            },
            {
                path: '/about',
                element: <AboutUs></AboutUs>
            },
            {
                path: '/pending-requests',
                element: <DonationRequests></DonationRequests>
            },
            {
                path: '/details/:id',
                element: <PrivateRoute><DonationDetails></DonationDetails></PrivateRoute>
            }
        ]
    },
    {
        path: '/dashboard',
        element: <PrivateRoute><DashboardLayout></DashboardLayout></PrivateRoute>,
        children: [
            {
                index: true,
                element: <MainDashboard></MainDashboard>
            },
            {
                path: 'create-request',
                element: <CreateRequest></CreateRequest>
            },
            {
                path: 'all-users',
                element: <AdminRoutes><AllUsers /></AdminRoutes>
            },
            {
                path: 'all-requests-admin',
                element: <AdminRoutes><AllRequestAdmin /></AdminRoutes>
            },
            {
                path: 'all-requests-volunteer',
                element: <VolunteerRoutes><AllRequestVolunteer /></VolunteerRoutes>
            },
            {
                path: 'my-requests',
                element: <MyRequests></MyRequests>
            },
            {
                path: 'edit-my-request/:id',
                element: <EditRequest></EditRequest>
            },
            {
                path: 'profile',
                element: <Profile></Profile>
            },
            {
                path: 'review',
                element: <Review></Review>
            }

        ]
    }

]);

export default router;